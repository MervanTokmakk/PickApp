﻿namespace KomOchHämta.Views.Products
{
	public class AboutUsVM
	{
	}
}
